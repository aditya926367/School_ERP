import { useMemo, useState } from "react";
import {
  Award,
  BookOpen,
  CalendarDays,
  Download,
  Search,
  TrendingUp,
  X,
  Eye,
} from "lucide-react";

type SubjectResult = {
  subject: string;
  marks: number;
  total: number;
  grade: string;
  remarks: string;
};

type ExamResult = {
  id: number;
  exam: string;
  student: string;
  className: string;
  date: string;
  subjects: SubjectResult[];
};

const results: ExamResult[] = [
  {
    id: 1,
    exam: "Mid-Term Examination",
    student: "Aarav Sharma",
    className: "8-A",
    date: "2026-09-25",
    subjects: [
      { subject: "English", marks: 82, total: 100, grade: "A", remarks: "Very Good" },
      { subject: "Mathematics", marks: 91, total: 100, grade: "A+", remarks: "Excellent" },
      { subject: "Science", marks: 86, total: 100, grade: "A", remarks: "Very Good" },
      { subject: "Social Studies", marks: 78, total: 100, grade: "B+", remarks: "Good" },
      { subject: "Computer", marks: 95, total: 100, grade: "A+", remarks: "Excellent" },
      { subject: "Hindi", marks: 80, total: 100, grade: "A", remarks: "Very Good" },
    ],
  },
  {
    id: 2,
    exam: "Unit Test 2",
    student: "Aarav Sharma",
    className: "8-A",
    date: "2026-08-20",
    subjects: [
      { subject: "English", marks: 40, total: 50, grade: "A", remarks: "Very Good" },
      { subject: "Mathematics", marks: 46, total: 50, grade: "A+", remarks: "Excellent" },
      { subject: "Science", marks: 43, total: 50, grade: "A", remarks: "Very Good" },
      { subject: "Social Studies", marks: 38, total: 50, grade: "B+", remarks: "Good" },
      { subject: "Computer", marks: 47, total: 50, grade: "A+", remarks: "Excellent" },
      { subject: "Hindi", marks: 41, total: 50, grade: "A", remarks: "Very Good" },
    ],
  },
  {
    id: 3,
    exam: "Mid-Term Examination",
    student: "Anaya Sharma",
    className: "5-B",
    date: "2026-09-25",
    subjects: [
      { subject: "English", marks: 88, total: 100, grade: "A", remarks: "Very Good" },
      { subject: "Mathematics", marks: 94, total: 100, grade: "A+", remarks: "Excellent" },
      { subject: "Science", marks: 90, total: 100, grade: "A+", remarks: "Excellent" },
      { subject: "Social Studies", marks: 85, total: 100, grade: "A", remarks: "Very Good" },
      { subject: "Computer", marks: 96, total: 100, grade: "A+", remarks: "Excellent" },
      { subject: "Hindi", marks: 84, total: 100, grade: "A", remarks: "Very Good" },
    ],
  },
];

const currencyPercent = (marks: number, total: number) =>
  total > 0 ? Math.round((marks / total) * 10000) / 100 : 0;

const formatDate = (date: string) =>
  new Date(`${date}T00:00:00`).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

function getSummary(result: ExamResult) {
  const obtained = result.subjects.reduce((sum, subject) => sum + subject.marks, 0);
  const maximum = result.subjects.reduce((sum, subject) => sum + subject.total, 0);
  const percentage = currencyPercent(obtained, maximum);

  return {
    obtained,
    maximum,
    percentage,
    grade: percentage >= 90 ? "A+" : percentage >= 80 ? "A" : percentage >= 70 ? "B+" : percentage >= 60 ? "B" : "C",
  };
}

function exportReport(result: ExamResult) {
  const summary = getSummary(result);
  const lines = [
    "School ERP - Academic Report",
    `Student: ${result.student}`,
    `Class: ${result.className}`,
    `Examination: ${result.exam}`,
    `Result Date: ${formatDate(result.date)}`,
    "",
    "Subject,Marks Obtained,Maximum Marks,Grade,Remarks",
    ...result.subjects.map((subject) =>
      [subject.subject, subject.marks, subject.total, subject.grade, subject.remarks]
        .map((value) => `"${String(value).replace(/"/g, '""')}"`)
        .join(","),
    ),
    "",
    `Total Marks,${summary.obtained}`,
    `Maximum Marks,${summary.maximum}`,
    `Percentage,${summary.percentage}%`,
    `Overall Grade,${summary.grade}`,
    "",
    
  ];

  const blob = new Blob(["\uFEFF" + lines.join("\n")], {
    type: "text/csv;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${result.student.replace(/\s+/g, "-")}-${result.exam.replace(/\s+/g, "-")}-results.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

export default function ParentResults() {
  const [studentFilter, setStudentFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [selectedResult, setSelectedResult] = useState<ExamResult | null>(null);

  const filteredResults = useMemo(() => {
    const query = search.trim().toLowerCase();

    return results.filter((result) => {
      const matchesStudent =
        studentFilter === "All" || result.student === studentFilter;
      const matchesSearch =
        result.exam.toLowerCase().includes(query) ||
        result.student.toLowerCase().includes(query) ||
        result.className.toLowerCase().includes(query);

      return matchesStudent && matchesSearch;
    });
  }, [studentFilter, search]);

  const latestResult = results[0];
  const latestSummary = getSummary(latestResult);

  return (
        <div className="min-h-screen space-y-6 bg-slate-50 p-4 sm:p-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Academic Results</h1>
        <p className="mt-1 text-sm text-gray-500">
          Review your children's examination performance and report cards.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Latest Percentage</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">
                {latestSummary.percentage}%
              </p>
              <p className="mt-1 text-xs text-gray-500">{latestResult.exam}</p>
            </div>
            <div className="rounded-xl bg-blue-100 p-3 text-blue-700">
              <TrendingUp size={24} />
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Overall Grade</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">
                {latestSummary.grade}
              </p>
              <p className="mt-1 text-xs text-gray-500">Latest available result</p>
            </div>
            <div className="rounded-xl bg-green-100 p-3 text-green-700">
              <Award size={24} />
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Examinations</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">
                {results.length}
              </p>
              <p className="mt-1 text-xs text-gray-500">Available  reports</p>
            </div>
            <div className="rounded-xl bg-purple-100 p-3 text-purple-700">
              <BookOpen size={24} />
            </div>
          </div>
        </div>
      </div>

      <section className="rounded-xl border border-gray-200 bg-white p-4">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <div className="relative">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search examination or student..."
              className="w-full rounded-lg border border-gray-200 py-2.5 pl-10 pr-3 text-sm outline-none focus:border-blue-500"
            />
          </div>

          <select
            value={studentFilter}
            onChange={(event) => setStudentFilter(event.target.value)}
            className="rounded-lg border border-gray-200 px-3 py-2.5 text-sm outline-none focus:border-blue-500"
          >
            <option value="All">All Children</option>
            <option value="Aarav Sharma">Aarav Sharma</option>
            <option value="Anaya Sharma">Anaya Sharma</option>
          </select>
        </div>
      </section>

      <section className="space-y-4">
        {filteredResults.length === 0 ? (
          <div className="rounded-xl border border-gray-200 bg-white p-10 text-center text-sm text-gray-500">
            No examination results found.
          </div>
        ) : (
          filteredResults.map((result) => {
            const summary = getSummary(result);

            return (
              <div
                key={result.id}
                className="rounded-xl border border-gray-200 bg-white p-5"
              >
                <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
                  <div>
                    <div className="flex items-center gap-2">
                      <div className="rounded-lg bg-blue-100 p-2 text-blue-700">
                        <BookOpen size={20} />
                      </div>
                      <h2 className="text-lg font-semibold text-gray-900">
                        {result.exam}
                      </h2>
                    </div>

                    <p className="mt-3 text-sm text-gray-700">{result.student}</p>
                    <div className="mt-2 flex flex-wrap gap-4 text-xs text-gray-500">
                      <span>Class: {result.className}</span>
                      <span className="inline-flex items-center gap-1">
                        <CalendarDays size={14} />
                        {formatDate(result.date)}
                      </span>
                    </div>
                  </div>

                  <div className="flex gap-5 rounded-lg bg-gray-50 p-4">
                    <div>
                      <p className="text-xs text-gray-500">Marks</p>
                      <p className="mt-1 font-bold text-gray-900">
                        {summary.obtained}/{summary.maximum}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Percentage</p>
                      <p className="mt-1 font-bold text-blue-700">
                        {summary.percentage}%
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Grade</p>
                      <p className="mt-1 font-bold text-green-700">{summary.grade}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-5 h-2 overflow-hidden rounded-full bg-gray-100">
                  <div
                    className="h-full rounded-full bg-blue-600"
                    style={{ width: `${summary.percentage}%` }}
                  />
                </div>

                <div className="mt-5 flex flex-wrap justify-end gap-3">
                  <button
                    onClick={() => setSelectedResult(result)}
                    className="inline-flex items-center gap-2 rounded-lg border border-gray-200 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50"
                  >
                    <Eye size={16} />
                    View Report
                  </button>
                  <button
                    onClick={() => exportReport(result)}
                    className="inline-flex items-center gap-2 rounded-lg bg-[#27348b] px-4 py-2 text-sm font-semibold text-white hover:bg-[#202b75]"
                  >
                    <Download size={16} />
                    Export Report
                  </button>


                </div>
              </div>
            );
          })
        )}
      </section>

      {selectedResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-xl bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-gray-200 p-5">
              <div>
                <h2 className="text-lg font-bold text-gray-900">Report Card</h2>
                <p className="mt-1 text-sm text-gray-500">
                  {selectedResult.student} · {selectedResult.exam}
                </p>
              </div>
              <button
                onClick={() => setSelectedResult(null)}
                className="rounded-lg p-2 text-gray-500 hover:bg-gray-100"
                aria-label="Close report card"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-5">
              <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  ["Student", selectedResult.student],
                  ["Class", selectedResult.className],
                  ["Examination", selectedResult.exam],
                  ["Result Date", formatDate(selectedResult.date)],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-lg bg-gray-50 p-3">
                    <p className="text-xs text-gray-500">{label}</p>
                    <p className="mt-1 text-sm font-semibold text-gray-900">{value}</p>
                  </div>
                ))}
              </div>

              <div className="overflow-x-auto">
                <table className="w-full min-w-[550px] text-left">
                  <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                    <tr>
                      <th className="px-4 py-3">Subject</th>
                      <th className="px-4 py-3">Marks</th>
                      <th className="px-4 py-3">Percentage</th>
                      <th className="px-4 py-3">Grade</th>
                      <th className="px-4 py-3">Remarks</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {selectedResult.subjects.map((subject) => (
                      <tr key={subject.subject}>
                        <td className="px-4 py-3 text-sm font-medium text-gray-900">{subject.subject}</td>
                        <td className="px-4 py-3 text-sm text-gray-700">{subject.marks}/{subject.total}</td>
                        <td className="px-4 py-3 text-sm text-gray-700">{currencyPercent(subject.marks, subject.total)}%</td>
                        <td className="px-4 py-3 text-sm font-semibold text-blue-700">{subject.grade}</td>
                        <td className="px-4 py-3 text-sm text-gray-600">{subject.remarks}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-5 flex flex-col justify-between gap-3 rounded-lg bg-blue-50 p-4 sm:flex-row sm:items-center">
                <div>
                  <p className="text-sm text-gray-600">Total Score</p>
                  <p className="text-xl font-bold text-gray-900">
                    {getSummary(selectedResult).obtained}/
                    {getSummary(selectedResult).maximum}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Overall Percentage</p>
                  <p className="text-xl font-bold text-blue-700">
                    {getSummary(selectedResult).percentage}%
                  </p>
                </div>
                <button
                  onClick={() => exportReport(selectedResult)}
                  className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#27348b] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#202b75]"
                >
                  <Download size={16} />
                  Export CSV
                </button>
              </div>

              
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
